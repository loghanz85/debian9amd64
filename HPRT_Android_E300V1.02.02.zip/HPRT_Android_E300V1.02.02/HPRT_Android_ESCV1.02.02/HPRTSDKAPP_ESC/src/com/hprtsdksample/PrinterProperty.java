package com.hprtsdksample;

public class PrinterProperty
{
	public static String Barcode="";
	public static int PrintableWidth=0;
	public static boolean Cut=false;
	public static int CutSpacing=0;
	public static int TearSpacing=0;
	public static int ConnectType=0;
	public static boolean Cashdrawer=false;
	public static boolean Buzzer=false;
	public static boolean Pagemode=false;
	public static String PagemodeArea="";
	public static boolean GetRemainingPower=false;
	public static boolean SampleReceipt=true;
	public static int StatusMode=0;
}